import javax.swing.*;
public class Main extends TravelAgency {
    public Main(JFrame parent) {
        super(parent);
    }

    public static void main(String[] args) {


        TravelAgency travel = new TravelAgency(null);

        if (LoginComplete == 1) {

            MenuTravelAgency menu = new MenuTravelAgency(null);


            }

        }

    }

